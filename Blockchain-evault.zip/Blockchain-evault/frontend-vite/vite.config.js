import { defineConfig } from 'vite';
import  react from '@vitejs/plugin-react';
//import dns from 'node:dns'
// https://vitejs.dev/config/
//dns.setDefaultResultOrder('verbatim')
export default defineConfig({
  server: {
    watch:{
      usePolling:true,
    },
    plugins:[react()],
    root: 'src',
    server:{port: 5173}
    //host: '0.0.0.0',
    //port: 5173, // Specify your port number here
    
  },
});

